import org.junit.Test;

import java.io.IOException;

public class CompetitionTests {

    @Test
    public void testDijkstraConstructor() {
        int minTime = new CompetitionDijkstra("./1000EWD.txt", 75, 56, 87).timeRequiredforCompetition();
        System.out.println("Time is " + minTime);
        assert(minTime != -1);
        //TODO
    }

    @Test
    public void testFWConstructor() {
        int minTime = new CompetitionFloydWarshall("./1000EWD.txt", 75, 56, 87).timeRequiredforCompetition();
        System.out.println("Time is " + minTime);
        assert(minTime != -1);
    }

    //TODO - more tests
    
}
