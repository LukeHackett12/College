public class DirectedEdge {
    public int v;
    public int w;
    public double weight;

    public DirectedEdge(int v, int w, double weight){
        this.v = v;
        this.w = w;
        this.weight = weight;
    }
}